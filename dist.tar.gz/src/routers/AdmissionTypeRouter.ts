import {Router} from "express";
import {verifyJwtToken} from "../middilwares/Security";
import {enter_personal_data_manual} from "../controller/AdmissionController";
import {create, getAll, remove, update} from "../controller/AdmissionTypeController";

const router: Router = Router();

router.route('/create')
    .post(verifyJwtToken('admin'), create);

router.route('/update/:id')
    .put(verifyJwtToken('admin'), update);

router.route('/delete/:id')
    .delete(verifyJwtToken('admin'), remove);

router.route('/all')
    .get(getAll);


export default router;
